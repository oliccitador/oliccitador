"use strict";exports.id=824,exports.ids=[824],exports.modules={72824:(e,o,c)=>{c.d(o,{buscarModuloCA:()=>s});var i=c(11258);async function r(e,o=""){console.log(`[CA-MODULE] Searching for CA ${e} information using AI...`);try{let c=process.env.GOOGLE_API_KEY;if(!c)return console.error("[CA-MODULE] GOOGLE_API_KEY not found"),null;let r=new i.$D(c).getGenerativeModel({model:"gemini-2.0-flash-exp"}),s=`
Voc\xea \xe9 um especialista em EPIs (Equipamentos de Prote\xe7\xe3o Individual) e CAs (Certificados de Aprova\xe7\xe3o) do Minist\xe9rio do Trabalho e Emprego (MTE).

CONTEXTO:
O usu\xe1rio informou um CA: ${e}
Descri\xe7\xe3o do item: "${o}"

TAREFA:
Com base no seu conhecimento sobre EPIs e CAs brasileiros, forne\xe7a:
1. "nome_comercial": Nome comercial t\xedpico do produto com este CA (como aparece em cat\xe1logos/an\xfancios)
2. "descricao_tecnica": Especifica\xe7\xe3o t\xe9cnica m\xednima do produto certificado (materiais, tipo de prote\xe7\xe3o, caracter\xedsticas essenciais)

REGRAS IMPORTANTES:
1. Use apenas conhecimento real sobre EPIs brasileiros
2. Se n\xe3o tiver certeza sobre este CA espec\xedfico, use a descri\xe7\xe3o do item para inferir o tipo de EPI
3. Seja espec\xedfico e t\xe9cnico na descri\xe7\xe3o
4. N\xe3o invente marcas ou modelos espec\xedficos
5. Foque nas caracter\xedsticas gen\xe9ricas do tipo de EPI

FORMATO DE SA\xcdDA (JSON):
{
  "nome_comercial": "Nome do tipo de EPI",
  "descricao_tecnica": "Especifica\xe7\xe3o t\xe9cnica detalhada"
}

Se n\xe3o houver informa\xe7\xf5es suficientes, retorne: { "erro": "Informa\xe7\xf5es insuficientes" }
`,a=await r.generateContent(s),n=(await a.response).text().replace(/```json\s*/g,"").replace(/```\s*/g,"").match(/\{[\s\S]*\}/);if(n){let o=JSON.parse(n[0]);if(o.erro)return console.warn(`[CA-MODULE] AI could not extract info for CA ${e}`),null;if(o.nome_comercial&&o.descricao_tecnica)return console.log(`[CA-MODULE] Successfully extracted info for CA ${e}`),{ca_detectado:e,nome_comercial:o.nome_comercial,descricao_tecnica:o.descricao_tecnica,mensagem_usuario:"Este produto foi identificado a partir do CA informado. Recomendamos tamb\xe9m consultar a descri\xe7\xe3o t\xe9cnica, pois existem outros modelos no mercado com as mesmas especifica\xe7\xf5es e pre\xe7os diferentes, inclusive com CAs distintos."}}return null}catch(o){return console.error(`[CA-MODULE] Error searching for CA ${e}:`,o.message),null}}async function s(e){let o=function(e){if(!e)return null;let o=e.match(/(?:CA|ca)[\s:.-]*(\d{5,6})/i);return o&&o[1]?(console.log(`[CA-MODULE] CA detected: ${o[1]}`),o[1]):null}(e);return o?await r(o,e):(console.log("[CA-MODULE] No CA detected, skipping module"),null)}}};